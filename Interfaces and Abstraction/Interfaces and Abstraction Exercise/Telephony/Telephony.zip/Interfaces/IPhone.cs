﻿namespace Telephony
{
    public interface IPhone
    {
        public void Call(string number);
    }
}
