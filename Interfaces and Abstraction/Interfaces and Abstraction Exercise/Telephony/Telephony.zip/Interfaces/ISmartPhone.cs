﻿namespace Telephony
{
    public interface ISmartPhone : IPhone
    {
        public void Browse(string site);
    }
}
