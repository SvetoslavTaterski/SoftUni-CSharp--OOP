﻿namespace Border_Control
{
    public interface IMachine
    {
        public string Model { get; set; }
        public string Id { get; set; }
    }
}
