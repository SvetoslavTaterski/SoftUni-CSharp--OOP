﻿namespace Border_Control.Interfaces
{

    public interface IBirthable
    {
        public string BirthDate { get; set; }
    }
}
