﻿namespace Border_Control
{
    using System;
    using System.Collections.Generic;

    using Classes;
    using Interfaces;

    public class StartUp
    {
        static void Main(string[] args)
        {
            List<Citizen> citizens = new List<Citizen>();
            List<Robot> robots = new List<Robot>();
            List<Pet> pets = new List<Pet>();
            List<IBirthable> citizensAndPets = new List<IBirthable>();

            while (true)
            {
                string command = Console.ReadLine();

                if (command == "End")
                {
                    break;
                }

                string[] tokens = command.Split(" ", StringSplitOptions.RemoveEmptyEntries);
                string action = tokens[0];

                if (action == "Citizen")
                {
                    string name = tokens[1];
                    int age = int.Parse(tokens[2]);
                    string id = tokens[3];
                    string birthdate = tokens[4];

                    Citizen newCitizen = new Citizen(name, age, id, birthdate);
                    citizensAndPets.Add(newCitizen);
                }
                else if (action == "Robot")
                {
                    string model = tokens[1];
                    string id = tokens[2];

                    Robot newRobot = new Robot(model, id);
                    robots.Add(newRobot);
                }
                else if (action == "Pet")
                {
                    string name = tokens[1];
                    string birthdate = tokens[2];

                    Pet newPet = new Pet(name,birthdate);
                    citizensAndPets.Add(newPet);
                }
            }

            string year = Console.ReadLine();


            foreach (IBirthable citizenOrPet in citizensAndPets)
            {
                if (citizenOrPet.BirthDate.EndsWith(year))
                {
                    Console.WriteLine(citizenOrPet.BirthDate);
                }
            }
        }
    }
}
