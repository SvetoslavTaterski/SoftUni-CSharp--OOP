﻿namespace Border_Control
{
    public interface IPerson
    {
        public string Name { get; set; }
        public int Age { get; set; }
    }
}
