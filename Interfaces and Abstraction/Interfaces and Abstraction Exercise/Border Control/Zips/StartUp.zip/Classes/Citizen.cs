﻿namespace Border_Control
{
    public class Citizen : IPerson
    {
        public Citizen(string name, int age, string id)
        {
            Name = name;
            Age = Age;
            Id = id;
        }

        public string Name { get; set; }
        public int Age { get; set; }
        public string Id { get; set; }
    }
}
