﻿namespace Border_Control
{
    using System;
    using System.Collections.Generic;

    public class StartUp
    {
        static void Main(string[] args)
        {
            List<Citizen> citizens = new List<Citizen>();
            List<Robot> robots = new List<Robot>();

            while (true)
            {
                string command = Console.ReadLine();

                if (command == "End")
                {
                    break;
                }

                string[] tokens = command.Split(" ", StringSplitOptions.RemoveEmptyEntries);

                if (tokens.Length == 3)
                {
                    string name = tokens[0];
                    int age = int.Parse(tokens[1]);
                    string id = tokens[2];

                    Citizen newCitizen = new Citizen(name, age, id);
                    citizens.Add(newCitizen);
                }
                else
                {
                    string model = tokens[0];
                    string id = tokens[1];

                    Robot newRobot = new Robot(model, id);
                    robots.Add(newRobot);
                }
            }

            string fakeIdNumber = Console.ReadLine();


            foreach (Robot robot in robots)
            {
                if (robot.Id.EndsWith(fakeIdNumber))
                {
                    Console.WriteLine(robot.Id);
                }
            }

            foreach (Citizen citizen in citizens)
            {
                if (citizen.Id.EndsWith(fakeIdNumber))
                {
                    Console.WriteLine(citizen.Id);
                }
            }
        }
    }
}
