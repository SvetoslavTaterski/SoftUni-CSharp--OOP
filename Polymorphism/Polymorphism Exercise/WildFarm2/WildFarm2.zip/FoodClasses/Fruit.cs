﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _04._Wild_Farm
{
    public class Fruit : Food
    {
        public Fruit(int quantity)
            : base(quantity)
        { }
    }
}