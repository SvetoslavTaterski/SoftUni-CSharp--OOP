﻿namespace Vehicles.Classes
{
    using Interfaces;

    public class Truck : IVehicle
    {
        private const double FUEL_CONSUMPTION_INCREASED = 1.6;

        public Truck(double fuelQuantity, double fuelConsumption)
        {
            FuelQuantity = fuelQuantity;
            FuelConsumption = fuelConsumption + FUEL_CONSUMPTION_INCREASED;
        }

        public double FuelQuantity { get; private set; }

        public double FuelConsumption { get; private set; }

        public string Drive(double distance)
        {
            if (this.FuelQuantity < this.FuelConsumption * distance)
            {
                return "Truck needs refueling";
            }

            this.FuelQuantity -= this.FuelConsumption * distance;
            return $"Truck travelled {distance} km";
        }

        public void Refuel(double fuel)
        {
            FuelQuantity += fuel * 0.95;
        }

        public override string ToString()
        {
            return $"Truck: {FuelQuantity:f2}";
        }
    }
}
