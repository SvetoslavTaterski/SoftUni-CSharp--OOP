﻿namespace Vehicles.Classes
{
    using System;

    using Interfaces;

    public class Car : IVehicle
    {
        private const double FUEL_CONSUMPTION_INCREASED = 0.9;

        public Car(double fuelQuantity, double fuelConsumption)
        {
            FuelQuantity = fuelQuantity;
            FuelConsumption = fuelConsumption + FUEL_CONSUMPTION_INCREASED;
        }

        public double FuelQuantity { get; private set; }

        public double FuelConsumption { get; private set; }

        public string Drive(double distance)
        {
            if (this.FuelQuantity < this.FuelConsumption * distance)
            {
                return "Car needs refueling";
            }

            this.FuelQuantity -= this.FuelConsumption * distance;
            return $"Car travelled {distance} km";
        }

        public void Refuel(double fuel)
        {
            this.FuelQuantity += fuel;
        }

        public override string ToString()
        {
            return $"Car: {FuelQuantity:f2}";
        }
    }
}
